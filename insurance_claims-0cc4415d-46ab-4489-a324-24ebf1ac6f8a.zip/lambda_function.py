import json
import boto3
import pg8000
from datetime import datetime

def lambda_handler(event, context):
    stream_name = "claims-stream"
    sns_arn = "arn:aws:sns:eu-west-2:666127452756:sri"

    kinesis_client = boto3.client('kinesis')
    sns_client = boto3.client('sns')
    
    pg_conn = None
    try:
        # 1. Connect to DB
        pg_conn = pg8000.connect(
            host     = "13.42.152.118",
            database = "testdb",
            user     = "admin",
            password = "admin123",
            port     = 5432
        )
        cursor = pg_conn.cursor()

        # 2. Fetch data
        query = """SELECT claim_id, policy_id, claim_amount, claim_date, 
                   claim_status, incident_type, fraud_flag 
                   FROM sri.claims_inc;"""
        cursor.execute(query)
        rows = cursor.fetchall()
        
        if not rows:
            sns_client.publish(
                TopicArn=sns_arn,
                Subject="No Records Found",
                Message="Lambda executed but no records were found in the database."
            )
            return {'statusCode': 200, 'body': 'No records found'}

        # 3. Batching Logic
        batch = []
        total_sent = 0
        
        for row in rows:
            Vdata = {
                "claim_id": str(row[0]),
                "policy_id": str(row[1]),
                "claim_amount": int(row[2]),
                "claim_date": str(row[3]),
                "claim_status": str(row[4]),
                "incident_type": str(row[5]),
                "fraud_flag": int(row[6]),
                "processed_at": str(datetime.now())
            }
            
            batch.append({
                'Data': json.dumps(Vdata),
                'PartitionKey': str(row[0])
            })

            # Send batch once it reaches 100 records
            if len(batch) == 100:
                kinesis_client.put_records(
                    Records=batch,
                    StreamName=stream_name
                )
                total_sent += len(batch)
                batch = []

        # Send remaining records
        if batch:
            kinesis_client.put_records(
                Records=batch,
                StreamName=stream_name
            )
            total_sent += len(batch)

        success_message = f"Successfully sent {total_sent} records to {stream_name}!"

        # ✅ SNS Success Notification
        sns_client.publish(
            TopicArn=sns_arn,
            Subject="Lambda Success",
            Message=success_message
        )

        return {
            'statusCode': 200,
            'body': json.dumps(success_message)
        }

    except Exception as e:
        error_message = f"Failed: {str(e)}"
        print(error_message)

        # ❌ SNS Failure Notification
        sns_client.publish(
            TopicArn=sns_arn,
            Subject="Lambda Failure",
            Message=error_message
        )

        return {
            'statusCode': 500,
            'body': json.dumps(error_message)
        }

    finally:
        if pg_conn:
            pg_conn.close()